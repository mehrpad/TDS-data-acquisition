//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Automate.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAutomateForm *AutomateForm;
//---------------------------------------------------------------------------
__fastcall TAutomateForm::TAutomateForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAutomateForm::Button1Click(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------
