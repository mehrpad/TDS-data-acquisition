object AutomateForm: TAutomateForm
  Left = 406
  Top = 275
  Width = 633
  Height = 402
  Caption = 'Automation Commands'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 625
    Height = 375
    Align = alClient
    Caption = 'Panel1'
    TabOrder = 0
    object GroupBox1: TGroupBox
      Left = 1
      Top = 205
      Width = 623
      Height = 169
      Align = alBottom
      Caption = 'Status '
      TabOrder = 0
      object Memo1: TMemo
        Left = 2
        Top = 15
        Width = 619
        Height = 152
        Align = alClient
        Lines.Strings = (
          'Memo1')
        TabOrder = 0
      end
    end
    object Panel2: TPanel
      Left = 1
      Top = 1
      Width = 623
      Height = 204
      Align = alClient
      Caption = 'Panel2'
      TabOrder = 1
      object Panel3: TPanel
        Left = 1
        Top = 1
        Width = 621
        Height = 151
        Align = alClient
        Caption = 'Panel3'
        TabOrder = 0
        object GroupBox2: TGroupBox
          Left = 1
          Top = 1
          Width = 619
          Height = 149
          Align = alClient
          Caption = 'Options'
          TabOrder = 0
        end
      end
      object Panel4: TPanel
        Left = 1
        Top = 152
        Width = 621
        Height = 51
        Align = alBottom
        Caption = 'Panel4'
        TabOrder = 1
        object GroupBox3: TGroupBox
          Left = 1
          Top = 1
          Width = 619
          Height = 49
          Align = alClient
          Caption = 'GroupBox3'
          TabOrder = 0
          object Start: TButton
            Left = 160
            Top = 12
            Width = 89
            Height = 25
            Caption = '&Start'
            TabOrder = 0
          end
          object Button1: TButton
            Left = 304
            Top = 12
            Width = 89
            Height = 25
            Caption = 'Quit'
            TabOrder = 1
            OnClick = Button1Click
          end
        end
      end
    end
  end
end
