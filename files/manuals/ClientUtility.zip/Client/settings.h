//---------------------------------------------------------------------------

#ifndef settingsH
#define settingsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TTSettings : public TForm
{
__published:	// IDE-managed Components
    TPageControl *PageControl1;
    TTabSheet *TabSheet1;
    TButton *OkButton;
    TButton *ExitButton;
    TLabel *Label1;
    TEdit *coAddress;
    TLabel *Label2;
    TEdit *coPort;
    void __fastcall Exit(TObject *Sender);
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall OkButtonClick(TObject *Sender);
    void __fastcall ExitButtonClick(TObject *Sender);
private:	// User declarations
    String Server;
    int Port;
public:		// User declarations
    __fastcall TTSettings(TComponent* Owner);
    String GetAddress() {return Server;}
    void SetAddress(String currServer) {Server = currServer; }
    int GetPort() {return Port;}
    void SetPort (int wPort) {Port = wPort;}
};
//---------------------------------------------------------------------------
extern PACKAGE TTSettings *TSettings;
//---------------------------------------------------------------------------
#endif
