object Form2: TForm2
  Left = 474
  Top = 228
  Width = 528
  Height = 321
  Caption = 'The Client'
  Color = clBtnFace
  Constraints.MinHeight = 200
  Constraints.MinWidth = 200
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Menu = MainMenu1
  OldCreateOrder = False
  OnCreate = FormCreate
  DesignSize = (
    520
    275)
  PixelsPerInch = 96
  TextHeight = 13
  object ClientScreen: TMemo
    Left = 8
    Top = 16
    Width = 501
    Height = 223
    Anchors = [akLeft, akTop, akRight, akBottom]
    Constraints.MinHeight = 200
    Constraints.MinWidth = 200
    Lines.Strings = (
      '')
    ScrollBars = ssVertical
    TabOrder = 0
    OnKeyDown = ClientScreenKeyDown
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 252
    Width = 520
    Height = 23
    Panels = <
      item
        Width = 300
      end
      item
        Width = 300
      end>
    SimplePanel = False
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 520
    Height = 2
    Anchors = [akLeft, akTop, akRight]
    TabOrder = 2
  end
  object MainMenu1: TMainMenu
    Left = 352
    Top = 32
    object File1: TMenuItem
      Caption = 'File'
      object ConnectToServer: TMenuItem
        Caption = 'Connect'
        OnClick = ConnectToServerClick
      end
      object DisconnectServer: TMenuItem
        Caption = 'Disconnect'
        OnClick = DisconnectServerClick
      end
      object N1: TMenuItem
        Caption = '-'
      end
      object Exit1: TMenuItem
        Caption = 'Exit'
        OnClick = Exit1Click
      end
    end
    object Settings1: TMenuItem
      Caption = '&Options'
      object ConnectionSettings: TMenuItem
        Caption = '&Settings'
        OnClick = ConnectionSettingsClick
      end
      object Echoback1: TMenuItem
        AutoCheck = True
        Caption = '&Echoback'
        OnClick = Echoback1Click
      end
      object Pause1: TMenuItem
        AutoCheck = True
        Caption = 'Pause'
        OnClick = Pause1Click
      end
      object LineLengthTransmit1: TMenuItem
        Caption = 'test ASCII'
        OnClick = LineLengthTransmit1Click
      end
      object Close1: TMenuItem
        Caption = '&Close associated file'
        OnClick = Close1Click
      end
      object N3: TMenuItem
        Caption = '-'
      end
      object menuTxtFile: TMenuItem
        Caption = 'Send &Text File'
        OnClick = menuTxtFileClick
      end
      object N2: TMenuItem
        Caption = '-'
      end
      object AutomatedCommands1: TMenuItem
        AutoCheck = True
        Caption = 'Automated Commands'
        OnClick = AutomatedCommands1Click
      end
      object FloodCommands1: TMenuItem
        Caption = '&Flood Commands'
        OnClick = FloodCommands1Click
      end
      object Display1: TMenuItem
        Caption = 'Display'
        Checked = True
        OnClick = Display1Click
      end
    end
    object IdentMenu: TMenuItem
      Caption = '&Identification'
      object Broadcast1: TMenuItem
        Caption = '&Broadcast'
        Visible = False
        OnClick = Broadcast1Click
      end
      object HostNameMenu: TMenuItem
        Caption = 'GetHostByName'
        OnClick = HostNameMenuClick
      end
    end
  end
  object ClientSocket: TClientSocket
    Active = False
    ClientType = ctNonBlocking
    Host = 'pc18'
    Port = 5026
    OnConnect = ClientSocketConnect
    OnDisconnect = ClientSocketDisconnect
    OnRead = ClientSocketRead
    OnError = ClientSocketError
    Left = 400
    Top = 16
  end
  object ARP: TUdpSocket
    BlockMode = bmNonBlocking
    LocalHost = '192.9.201.28'
    OnReceive = ARPReceive
    Left = 272
    Top = 16
  end
  object TheTimer: TTimer
    Enabled = False
    Interval = 60000
    OnTimer = TheTimerTimer
    Left = 376
    Top = 96
  end
end
