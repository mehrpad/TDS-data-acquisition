//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USEFORM("Client.cpp", Form2);
USEFORM("settings.cpp", TSettings);
USEFORM("Automate.cpp", AutomateForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
         Application->Initialize();
         Application->CreateForm(__classid(TForm2), &Form2);
         Application->CreateForm(__classid(TTSettings), &TSettings);
         Application->Run();

    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
