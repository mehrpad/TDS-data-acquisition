//---------------------------------------------------------------------------

#ifndef ClientH
#define ClientH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <ScktComp.hpp>
#include <Sockets.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdTrivialFTP.hpp>
#include <IdUDPBase.hpp>
#include <IdUDPClient.hpp>
#include <Dialogs.hpp>
#include <map>
#include <deque>
#include "TCommand.h"
using namespace std;


typedef map<string, string > CommandBlock;

typedef deque<TCommand *> RecvCommandList;
typedef deque<TCommand * >::iterator RecvCommandIt;



#define DELIMITER       ","
#define CRLF            "\r\n"
#define CR              "\n"

//---------------------------------------------------------------------------
// contruct an BOOTP header
typedef struct
{
    unsigned char bp_op;            // 1=Request, 2 = Reply
    unsigned char bp_hrd;           // Hardware Type, 1 = Ethernet
    unsigned char bp_sha[6];        // Sender's Ethernet Address length ,6 = ethernet
    unsigned char bp_hop;           // Hop Count
    unsigned long bp_xid;           // Transaction ID
    unsigned short bp_seconds;      // number of seconds
    unsigned short bp_unused;       // unused
    unsigned char bp_cip[4];        // Client IP address
    unsigned char bp_yip[4];        // Your ip address
    unsigned char bp_sip[4];        // Server IP address
    unsigned char bp_gip[4];        // Gateway IP address
    unsigned char bp_cha[6];        // Clients Hardware address;
    unsigned char bp_shname[64];    // Servers Hostname
    unsigned char bp_fname[128];    // boot filename
    unsigned char bp_venspec[64];  // Vendor specific info
} bootp_hdr;


class TForm2 : public TForm
{
__published:	// IDE-managed Components
    TMainMenu *MainMenu1;
    TMenuItem *File1;
    TMenuItem *ConnectToServer;
    TMenuItem *DisconnectServer;
    TMenuItem *N1;
    TMenuItem *Exit1;
    TMemo *ClientScreen;
    TStatusBar *StatusBar1;
    TPanel *Panel1;
    TClientSocket *ClientSocket;
    TMenuItem *Settings1;
    TMenuItem *Echoback1;
    TMenuItem *Pause1;
    TMenuItem *LineLengthTransmit1;
    TUdpSocket *ARP;
    TMenuItem *IdentMenu;
    TMenuItem *Broadcast1;
    TMenuItem *HostNameMenu;
    TMenuItem *ConnectionSettings;
    TMenuItem *N2;
    TMenuItem *AutomatedCommands1;
    TTimer *TheTimer;
    TMenuItem *Display1;
    TMenuItem *N3;
    TMenuItem *menuTxtFile;
    TMenuItem *Close1;
    TMenuItem *FloodCommands1;
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall ConnectToServerClick(TObject *Sender);
    void __fastcall ClientSocketConnect(TObject *Sender,
          TCustomWinSocket *Socket);
    void __fastcall ClientScreenKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DisconnectServerClick(TObject *Sender);
    void __fastcall ClientSocketError(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
    void __fastcall ClientSocketRead(TObject *Sender,
          TCustomWinSocket *Socket);
    void __fastcall ClientSocketDisconnect(TObject *Sender,
          TCustomWinSocket *Socket);
    void __fastcall SetAddressClick(TObject *Sender);
    void __fastcall SetPortClick(TObject *Sender);
    void __fastcall Echoback1Click(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall Pause1Click(TObject *Sender);
    void __fastcall LineLengthTransmit1Click(TObject *Sender);
    void __fastcall Broadcast1Click(TObject *Sender);
    void __fastcall ARPReceive(TObject *Sender, PChar Buf, int &DataLen);
    void __fastcall ServerReceive(TObject *Sender, PChar Buf,
          int &DataLen);
    void __fastcall HostNameMenuClick(TObject *Sender);
    void __fastcall ConnectionSettingsClick(TObject *Sender);
    void __fastcall AutomatedCommands1Click(TObject *Sender);
    void __fastcall TheTimerTimer(TObject *Sender);
    void __fastcall Display1Click(TObject *Sender);
    void __fastcall menuTxtFileClick(TObject *Sender);
    void __fastcall Close1Click(TObject *Sender);
    void __fastcall FloodCommands1Click(TObject *Sender);


private:	// User declarations
//    map<string, string > m_CommandBlock;
//    map<string, string>::iterator itr;
    CommandBlock m_CommandBlock;
    CommandBlock::iterator itr;
    RecvCommandList m_CommandList;
    RecvCommandIt CommandIterator;

    TClientSocket *clSock1, *clSock2, *clAutoSock;
    TSendCommand *pContinue;
    String Server;
    int Port;
    int LastLine;
    int LineRec;
    int wTransmitLine;
    int wMessCount;
    AnsiString csLine,asString2Send,asResponse;
    bool bEcho,bPause,bTransmit,bAutomate,bReceived,bTimeOut;
    AnsiString ansiReceived;
    bootp_hdr ea; // ARP data packet
    bool bDisplay;
    bool m_bFileMode;
    bool m_bCloseRep;
    bool bFlood;


    bool __fastcall BuildCommands(TStringList *);
    bool __fastcall RunCommands(TStringList *);
    AnsiString __fastcall GetFileName();
    bool __fastcall ProcessFile(AnsiString asFile);
    void __fastcall SetFileMode(bool bValue) {m_bFileMode = bValue;}
    bool __fastcall GetFileMode() {return m_bFileMode;}
    bool __fastcall EmptyCommandContainer();
    AnsiString __fastcall GetRepeatCommand();
    void __fastcall OpenAutoSock();
    void __fastcall CloseAutoSock();

public:		// User declarations
    __fastcall TForm2(TComponent* Owner);
    bool __fastcall Send(AnsiString );
    bool __fastcall ReceivedReply() {return bReceived;}
    AnsiString __fastcall GetReply();
    bool __fastcall TimedOut() {return bTimeOut;}
    void __fastcall SetAutomate(bool bAuto) {bAutomate = bAuto;}
    bool __fastcall GetAutomateState() {return bAutomate;}
    AnsiString GetResponse() {return asResponse;}
    bool __fastcall CloseSocket();
    bool __fastcall OpenSocket();

};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
