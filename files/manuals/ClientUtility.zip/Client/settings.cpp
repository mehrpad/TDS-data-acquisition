//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "settings.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTSettings *TSettings;
//---------------------------------------------------------------------------
__fastcall TTSettings::TTSettings(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTSettings::Exit(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------


void __fastcall TTSettings::FormActivate(TObject *Sender)
{
    // Dialog box has been activated so need to display the current values
    coAddress->Text = Server;
    coPort->Text = Port;
    // ensure Address control has the imnmediate focus.
    FocusControl(coAddress);
}
//---------------------------------------------------------------------------

void __fastcall TTSettings::OkButtonClick(TObject *Sender)
{
    Server = coAddress->Text;
    Port = coPort->Text.ToInt();
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TTSettings::ExitButtonClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

