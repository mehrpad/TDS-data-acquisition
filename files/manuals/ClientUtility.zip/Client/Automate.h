//---------------------------------------------------------------------------

#ifndef AutomateH
#define AutomateH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAutomateForm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TGroupBox *GroupBox1;
    TMemo *Memo1;
    TPanel *Panel2;
    TPanel *Panel3;
    TPanel *Panel4;
    TGroupBox *GroupBox3;
    TGroupBox *GroupBox2;
    TButton *Start;
    TButton *Button1;
    void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TAutomateForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAutomateForm *AutomateForm;
//---------------------------------------------------------------------------
#endif
