object TSettings: TTSettings
  Left = 450
  Top = 225
  BorderStyle = bsDialog
  Caption = 'Settings'
  ClientHeight = 270
  ClientWidth = 414
  Color = clBtnFace
  Constraints.MaxHeight = 297
  Constraints.MaxWidth = 422
  Constraints.MinHeight = 297
  Constraints.MinWidth = 422
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnActivate = FormActivate
  PixelsPerInch = 96
  TextHeight = 13
  object PageControl1: TPageControl
    Left = 8
    Top = 8
    Width = 393
    Height = 209
    ActivePage = TabSheet1
    TabIndex = 0
    TabOrder = 0
    object TabSheet1: TTabSheet
      Caption = 'Settings'
      object Label1: TLabel
        Left = 16
        Top = 34
        Width = 38
        Height = 13
        Caption = 'Address'
      end
      object Label2: TLabel
        Left = 16
        Top = 82
        Width = 19
        Height = 13
        Caption = 'Port'
      end
      object coAddress: TEdit
        Left = 64
        Top = 32
        Width = 217
        Height = 21
        TabOrder = 0
      end
      object coPort: TEdit
        Left = 64
        Top = 80
        Width = 217
        Height = 21
        TabOrder = 1
      end
    end
  end
  object OkButton: TButton
    Left = 120
    Top = 232
    Width = 65
    Height = 25
    Caption = '&Ok'
    TabOrder = 1
    OnClick = OkButtonClick
  end
  object ExitButton: TButton
    Left = 200
    Top = 232
    Width = 65
    Height = 25
    Caption = '&Exit'
    TabOrder = 2
    OnClick = ExitButtonClick
  end
end
