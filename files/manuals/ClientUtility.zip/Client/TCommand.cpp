//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TCommand.h"
#include "client.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TSendCommand::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
__fastcall TSendCommand::TSendCommand(bool CreateSuspended,TStringList *tslCommands) : TThread(CreateSuspended)
{
    Initialize(tslCommands);
}
//---------------------------------------------------------------------------
void __fastcall TSendCommand::Execute()
{
    //---- Place thread code here ----
    Priority = tpNormal;
    // Loop until finished.
    bool bState=true;
    WaitForResponse(true);
    do
    {
        wIndex=0;
        do
        {
          bState = ProcessCommand();
          if(bState)
          {
               // do we need to keep issuing the same command?  i.e. Status
/*               if(tslList->Strings[wIndex].AnsiPos("Status") > 0)
               {
                   bool bContinue=true;
                   do
                   {
                        AnsiString asValue = Form2->GetResponse();
                        if(asValue.AnsiPos("StoppedActive")>0 || asValue.AnsiPos("Available")>0 || asValue.AnsiPos("StoppedShutDown")>0)
                            bContinue = false;
                        else
                        {
                            bState = ProcessCommand();
                        }
                   } while(bContinue && bState);
               }
*/
          }
          if(wIndex<tslList->Count)
              wIndex++;
          Sleep(10);
          if(tslList->Strings[wIndex] == "*CLOSE*")
          {
            Form2->CloseSocket();
            Form2->OpenSocket();
            Sleep(10);
            if(wIndex<tslList->Count)
                wIndex++;

          }

        } while(wIndex < tslList->Count && Form2->GetAutomateState());
        Sleep(1000);
    }while(Form2->GetAutomateState());
    Terminate(!bState);
    if(tslList)
        delete tslList;

}
//---------------------------------------------------------------------------
// Sends one command from the TStringList to server and waits for the result.
bool __fastcall TSendCommand::ProcessCommand()
{
    bool bReturn=false;

    if(wIndex == tslList->Count)
        return bReturn;

    if(tslList->Strings[wIndex] == "*PAUSE*")
    {
        Sleep(1000);
        bReturn = true;
    }
    else
    // Check for internal action commands *CLOSE*
/*    if(tslList->Strings[wIndex] == "*CLOSE*")
    {
        Form2->CloseSocket();
        Form2->OpenSocket();
        bReturn = true;
    }
    else
*/
    {
        Form2->Send(tslList->Strings[wIndex]);

        if(bWaitResponse)
        {
            while(!Form2->ReceivedReply() && !Form2->TimedOut())
            {
                Sleep(10);
            }
        }
        bReturn = Form2->ReceivedReply();
    }
    return bReturn;
}
void __fastcall TSendCommand::Initialize(TStringList *tslCommands)
{
    if(tslCommands)
    {
        if(tslCommands->Count)
        {
            tslList = new TStringList;
            if(tslList)
            {
                tslList->Assign(tslCommands);
                wIndex = 0;
            }
            else
                bTerminate = true;
        }
        else
            bTerminate = true;
    }
    else
        bTerminate = true;
    wIndex=0;
}

