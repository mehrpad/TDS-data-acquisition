//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <fstream.h>
#include <process.h>
#include "Client.h"
#include "settings.h"
#include "Automate.h"
#include "TCommand.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;

//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner): TForm(Owner)
{
    Server    = "localhost";
    Port      = 5026;
    bReceived = false;
    bTimeOut  = false;
    bDisplay  = Display1->Checked;
    bFlood    = FloodCommands1->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Exit1Click(TObject *Sender)
{
    EmptyCommandContainer();
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm2::ConnectToServerClick(TObject *Sender)
{
    if(Server.Length()==0)
    {
        MessageBox(NULL,"Need to specify IP address to connect to","Address Error",MB_OK);
        return;
    }
    if(ClientSocket->Port == 0)
    {
        MessageBox(NULL,"Need to specify port number to establish connection with","Address Error",MB_OK);
        return;
    }
    // Need to determine the server user wishes to connect to.
    ClientSocket->Open();
//    ClientSocket1->Open();
//    ClientSocket2->Open();
    StatusBar1->Panels->Items[0]->Text = "Connecting to: " + Server;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::ClientSocketConnect(TObject *Sender,TCustomWinSocket *Socket)
{
    TCustomWinSocket *pSocket;

    StatusBar1->Panels->Items[0]->Text = "Connected to " +Socket->RemoteHost;
//    pSocket = ClientSocket->Socket;
    pSocket = Socket;
    setsockopt(pSocket->SocketHandle,IPPROTO_TCP,TCP_NODELAY,"1",sizeof(int));

    // init various state variables
    LastLine = 0;
    LineRec = 0;
    ClientScreen->Clear();


 //   delete pSocket;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ClientScreenKeyDown(TObject *Sender, WORD &Key,TShiftState Shift)
{
    int wLoop,wEnd;

    // Only interested if key pressed is the return key.  Return Key corresponds
    // to "send the info" to the server.
    if(Key == VK_RETURN)
    {
        // Will send the lines indicated by count - 1;  This will be the last line typed
        // by the user.
        wEnd = ClientScreen->Lines->Count;
        for(wLoop=LastLine;wLoop<wEnd;wLoop++)
        {
            ClientSocket->Socket->SendText(ClientScreen->Lines->Strings[wLoop]);
        }
        ClientSocket->Socket->SendText("\r\n");
        // set new marker point.
        LastLine = wEnd;
    } // if
}
//---------------------------------------------------------------------------

void __fastcall TForm2::DisconnectServerClick(TObject *Sender)
{
    ClientSocket->Active = false;
    StatusBar1->Panels->Items[0]->Text = "Disconnected";
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ClientSocketError(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
    char szOutput[256];

    sprintf(szOutput,"Error Occured - %d",ErrorCode);

    StatusBar1->Panels->Items[0]->Text = szOutput;
    // set error code to zero to indicate "dealt with", failure to do this results
    // in an exception being thrown.
    ErrorCode=0;
}
//---------------------------------------------------------------------------

// Called when the socket detects incoming data.
void __fastcall TForm2::ClientSocketRead(TObject *Sender,
      TCustomWinSocket *Socket)
{

    int wEndLine,wNewLine,wLoop;
    /* need to keep of track of current line pointer, in order to increment it
    , failure to do so means that the 'writing' code will send the response as well
    as the new data to be sent....clear ?  as mud ! lol */
    ansiReceived += Socket->ReceiveText();
    if(ansiReceived.AnsiPos("\r\n"))
    {
        TheTimer->Enabled = false;
        if(bDisplay)
        {
            ClientScreen->Lines->Add( ansiReceived);
            LastLine = ClientScreen->Lines->Count;
        }
        asResponse.Delete(1,asResponse.Length());
        asResponse = ansiReceived;


        if(bPause)
            ShowMessage("Press 'Ok' to cause a crash");

        if(bAutomate)
        {
            bReceived = true;

        }
        if(m_bCloseRep)
        {
            if(asResponse.Trim().AnsiCompareIC("1") != 0)
            {
                // Need to resend close command
                ClientSocket->Socket->SendText(GetRepeatCommand());
            }
            else
                m_bCloseRep = false;
        }

        // If echo back is on then we need to transmit this line back to the other
        // socket, need to ensure we have the entire data sequence from the dest.
        // socket by testing for CRLF
        if(bEcho)
        {
            if(wTransmitLine)
            {
                StatusBar1->Panels->Items[1]->Text = "Messages Received = " + IntToStr(wMessCount++);
                //ClientSocket->Socket->SendText(asString2Send);
                ClientSocket->Socket->SendText(ansiReceived);
            }
            else
                ClientSocket->Socket->SendText(ansiReceived);
        }
        ansiReceived = "";

    } // if AnsiPos

}
//---------------------------------------------------------------------------
void __fastcall TForm2::ClientSocketDisconnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
    StatusBar1->Panels->Items[0]->Text = "Server Disconnected";
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SetAddressClick(TObject *Sender)
{

    do
    {
        if(InputQuery("Server","Please enter the server you wish to connect to:",Server))
        {
            // Ensure user entered something rather than pressed return key.
            if(Server.Length()>0)
                ClientSocket->Host   = Server;
            else
                MessageBox(NULL,"Incorrect Address format","Address Error",MB_OK);
        }
    } while(Server.Length()==0);
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SetPortClick(TObject *Sender)
{
    AnsiString inputString="5150";

    if(Port !=0)
        inputString = IntToStr(Port);
    do
    {
        if(InputQuery("Server","Please enter the port you wish to connect to:",inputString))
        {
            if(inputString.Length())
            {
                try
                {
                    ClientSocket->Port = inputString.ToInt();
                    Port = ClientSocket->Port;
                }
                catch (Exception &E)
                {
//                    if (E.ClassNameIs("EConvertError"))
                      MessageBox(NULL,"The Port number was invalid, it must be an integer number","Invalid Port Entry",MB_OK);

                }

            }
            else
                MessageBox(NULL,"Incorrect Port","Port Error",MB_OK);
        }
    } while(inputString.Length()==0);

}
//---------------------------------------------------------------------------

void __fastcall TForm2::Echoback1Click(TObject *Sender)
{
    // User has elected to echo any received command from the peer socket
    // back to the peer socket.
    bEcho = !bEcho;
    if(bEcho)
        StatusBar1->Panels->Items[0]->Text="On";
    else
        StatusBar1->Panels->Items[0]->Text="Off";

}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormCreate(TObject *Sender)
{
    // Initialize variables
    LineRec = LastLine = wTransmitLine = wMessCount = 0;
    bEcho = false;
    bPause = false;
    bTransmit = false;
    csLine = "TEST ASCII 1 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789:;,.!$%&*-+=#@?<>>>>>>>>>>>>>>>";
}
//---------------------------------------------------------------------------

void __fastcall TForm2::Pause1Click(TObject *Sender)
{
    bPause=!bPause;
}
//---------------------------------------------------------------------------
/*
    Need the ability to set the length of the line to be transmitted.
    Selecting the pause option  should allow the changes to be made prior to
    next string being transmitted.
*/
void __fastcall TForm2::LineLengthTransmit1Click(TObject *Sender)
{
    AnsiString inputString="0";

    // Remember what the current choice is..
    wTransmitLine = 92;
/*    inputString = IntToStr(wTransmitLine);
    // start the loop
    do
    {
        if(InputQuery("Transmit Line Length","Please enter the MAXIMUM length of the line to be transmitted",inputString))
        {
            if(inputString.Length())
            {
                try
                {
                    wTransmitLine = inputString.ToInt();
                }
                catch (Exception &E)
                {
//                    if (E.ClassNameIs("EConvertError"))
                      MessageBox(NULL,"The number was invalid, it must be an integer number","Invalid Transmit Line Entry",MB_OK);
                }
            }
            else
                MessageBox(NULL,"Please enter a valid number","Transmit Line Error",MB_OK);
            if(wTransmitLine > csLine.Length())
            {
                ShowMessage("Line Length exceeds length of the test ASCII string!");
                inputString.SetLength(0);
            }
        }
        else
            return;
    } while(inputString.Length()==0);
*/
    // Now setup the ansistring containing our string to be sent
    if(wTransmitLine==0)
        asString2Send =csLine;
    else
    {
        asString2Send = csLine;
        asString2Send.SetLength(wTransmitLine);
    };
    asString2Send += "\r\n";
    // Transmit the line
    ClientScreen->Lines->Add(asString2Send);
    LastLine = ClientScreen->Lines->Count;
    ClientSocket->Socket->SendText(asString2Send);
    // update status bar message
    wMessCount = 0;
    StatusBar1->Panels->Items[1]->Text = "Message received = " + IntToStr(wMessCount);

}
//---------------------------------------------------------------------------
void __fastcall TForm2::Broadcast1Click(TObject *Sender)
{
    WORD wWord;
    sockaddr_in serverAddr;
    int sockfd,n;
    char buff[255];
    // This is the section of code that will broadcast out an ARP packet in order to determine
    // what the hardware address of a specfied ip address is.
    // The ip address is specified in the same place as normal (Settings->)

    // We will however still need to open the UDP socket before writing to it so
    // lets set up the local/remote details and open.
/*    sockfd = socket(PF_INET,SOCK_DGRAM,0);
    // set broadcast option
    setsockopt(sockfd,SOL_SOCKET,SO_BROADCAST,"1",sizeof(int));
    // fill in the structure info

    memset (&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("255.255.255.255");
    serverAddr.sin_port = htons(67);


    n = sendto(sockfd,(char *)&ea,sizeof(ea),0,(struct sockaddr *)&serverAddr,sizeof(serverAddr));
    memset(&buff,0,255);
    while(n = recvfrom(sockfd,buff,sizeof(buff),0,NULL,NULL))
    {
        ShowMessage(buff);
        memset(&buff,0,255);

    }
*/
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ARPReceive(TObject *Sender, PChar Buf,
      int &DataLen)
{
    // received a packet
    StatusBar1->Panels->Items[0]->Text = "Received UDP packet";

}
//---------------------------------------------------------------------------

void __fastcall TForm2::ServerReceive(TObject *Sender, PChar Buf,
      int &DataLen)
{
    ShowMessage("Server received something");
}
//---------------------------------------------------------------------------
/*******************************************************************************
** Function : HostNameMenuClick
** Date     : 07/10/02
** Author   : Brendan
** Purpose  : Test function to determine whether it is possible to get the IP
**          : address of the MSIU.
********************************************************************************/
void __fastcall TForm2::HostNameMenuClick(TObject *Sender)
{
    hostent *hTable;
    char *pszHostName;
//    char constName[] = "internet";
    char szOut[255];
    in_addr addr;
    unsigned int *p;
    AnsiString asHostName;

    do
    {
        if(InputQuery("Identify Host","Please enter the Hostname to be resolved",asHostName))
        {
            if(!asHostName.Length())
                MessageBox(NULL,"Please enter a Hostname","Hostname Error",MB_OK);
        }
    } while(asHostName.Length()==0);


    pszHostName = new char[255];
    memset(pszHostName,0,255);
    sprintf(pszHostName,"%s",asHostName);
    hTable = gethostbyname(pszHostName);
    if(!hTable)
    {
        // Failed to find it.
        sprintf(szOut,"%s -> %s",asHostName,"unknown");
        ClientScreen->Lines->Add(szOut);
    }
    else
    {

        p = (unsigned int *)hTable->h_addr;
        addr.s_addr = *p;
        pszHostName = inet_ntoa(addr);

        sprintf(szOut,"%s -> %s",asHostName,pszHostName);
        ClientScreen->Lines->Add(szOut);
//       ulAdd =  inet_addr(hTable->h_addr);
    }

    delete [] pszHostName;

}
//---------------------------------------------------------------------------
/*******************************************************************************
** Function : ConnectionSettingsClick
** Author   : Bren
** Date     : 07/03/03
** Input    :
** Output   :
** Purpose  : Provides the ability to set all the connection settings in one
**          : "go" via a dialog box, rather than be forced to use multiple
**          : pop up input query boxes. ie address, port.
********************************************************************************/
void __fastcall TForm2::ConnectionSettingsClick(TObject *Sender)
{
    // Initiate the dialog box call.
    TSettings->SetAddress(Server);
    TSettings->SetPort(Port);
    TSettings->ShowModal();
    Server = TSettings->GetAddress();
    Port = TSettings->GetPort();
    ClientSocket->Port = Port;
    ClientSocket->Host = Server;
}
//---------------------------------------------------------------------------
bool __fastcall TForm2::Send(AnsiString asString2Send)
{
    // Transmit the line
    if(bDisplay)
    {
        ClientScreen->Lines->Add(asString2Send);
        LastLine = ClientScreen->Lines->Count;
    }
    bReceived=false;
    bTimeOut=false;
    TheTimer->Enabled = true;
    if(ClientSocket->Socket->SendText(asString2Send)>0)
        return true;
    else
        return false;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::AutomatedCommands1Click(TObject *Sender)
{
    // Need a comment to stop BCB removing the method declaration.
//    TAutomateForm *pTAutomateForm = new TAutomateForm(this);
//    if(pTAutomateForm)
//        pTAutomateForm->ShowModal();

    try
    {
        if(!ClientSocket->Active)
        {
            ClientScreen->Lines->Add("Not connected to a server....");
            AutomatedCommands1->Checked = false;
        }
        else
        {
            if(!bAutomate)
            {
                TStringList *pslList = new TStringList;
                SetAutomate(true);
                unsigned long ulThreadID;
                try
                {
                    BuildCommands(pslList);
                    RunCommands(pslList);
                    delete pslList;
                    pslList = 0;
                }
                catch(...)
                {
                    ClientScreen->Lines->Add("Failed to initiate command sequence");
                }
            }
            else
            {
                pContinue->Terminate(true);
                SetAutomate(false);
            }
        }
    }
    catch(...)
    {
        ClientScreen->Lines->Add("Not connected to a server....");
        AutomatedCommands1->Checked = false;
    }
}

//---------------------------------------------------------------------------
bool __fastcall TForm2::BuildCommands(TStringList *pList)
{
    bool bReturnState=false;
    if(pList)
    {
      pList->Add("-fc:\\data files\\hiden analytical\\MASsoft\\Template\\MethodsV1Pro.exp\r\n");
      pList->Add("*PAUSE*");
      pList->Add("-xClose -d30\r\n");
      pList->Add("*CLOSE*");
      bReturnState = true;
    }
    return bReturnState;
}

bool __fastcall TForm2::RunCommands(TStringList *pList)
{
    bool bReturnState=false;
    TStringList *pslList = dynamic_cast<TStringList *>(pList);

    if(pslList)
    {
        if(pslList->Count)
        {
//            bool bState = Send(pslList->Strings[wIndex++]);
            bAutomate    = true;
            pContinue    = new TSendCommand(false,pslList);
            pContinue->WaitForResponse(bFlood);
            bReturnState = true;
        } // pslList->count
    }// if pslList
    return bReturnState;
}
void __fastcall TForm2::TheTimerTimer(TObject *Sender)
{
    bTimeOut = true;
    bReceived = false;

    TheTimer->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::Display1Click(TObject *Sender)
{
    bDisplay = !bDisplay;
    Display1->Checked = bDisplay;
}
//---------------------------------------------------------------------------
/*******************************************************************************
** Function : menuTxtFileClick
** Author   : Brendan
** Date     : 5/12/06
** Purpose  :
**          : Called when user wants to transmit a text file to the open socket.
**          : Requirements : Socket to be open and available
**          :
**          : Step(s) -> Get Valid file and open
**          :         -> Read in command(s) (separated by commas) and process
**          :         -> Send commands as a block.
**          :         -> Attach return values to each of the sent commands.
********************************************************************************/
void __fastcall TForm2::menuTxtFileClick(TObject *Sender)
{
    // only proceed if we have a socket.
    if(ClientSocket->Active)
    {
        AnsiString asFileName = GetFileName();
        if(!asFileName.IsEmpty())
        {
            if(ProcessFile(asFileName))
            {
                // We now have a map contaniner with comamnds..
                // indicate we're bulk transmitting..
                SetFileMode(true);
                string sCommand;

                CommandIterator = m_CommandList.begin();
                while(CommandIterator != m_CommandList.end())
                {
                    sCommand += (*CommandIterator)->GetCommand();
                    sCommand += CR;
                    CommandIterator++;
                }

                if(!ClientSocket->Socket->SendText(sCommand.c_str()))
                    SetFileMode(false);
            }
        }
    }
}
//---------------------------------------------------------------------------
/*******************************************************************************
** Function : GetFileName
** Author   : Brendan
** Date     : 06/12/06
** Purpose  : Presents a file dialogue box which allows the user to select the file
**          : that wish to open.
*******************************************************************************/
AnsiString __fastcall TForm2::GetFileName()
{
    AnsiString asFileName;
    TOpenDialog *pOpenDialog = new TOpenDialog(this);
    if(!pOpenDialog)
        return 0;

    pOpenDialog->Options << ofHideReadOnly << ofPathMustExist << ofFileMustExist;
    pOpenDialog->DefaultExt = "*.txt";
    pOpenDialog->Filter = "*.txt";

    if(pOpenDialog->Execute())
	{
        asFileName = pOpenDialog->FileName;
	}
    if(pOpenDialog)
        delete pOpenDialog;

    return asFileName;
}
/*******************************************************************************
** Function : ProcessFile
** Author   : Brendan
** Date     : 06/12/06
** Purpose  : using the specified filename; read in the commands (csv) and
**          : insert them into the command block.
**          : return true or false dependence on success.
*******************************************************************************/
bool __fastcall TForm2::ProcessFile(AnsiString asFile)
{
    bool bReturn = false;
    if(!asFile.IsEmpty())
    {
        int iFileHandle;

        try
        {
            iFileHandle = FileOpen(asFile,fmOpenRead);
            if(iFileHandle)
            {
                AnsiString asContents;
                int nBytesRead = 0;
                int iBeginPos, iEndPos;
                int iFileLength = FileSeek(iFileHandle,0,2);
                // Reset file pointer back to the beginning.
                FileSeek(iFileHandle,0,0);
                // Get the contents of the file...we cannot pass in an AnsiString
                char *pszBuffer = new char[iFileLength+1];
                // clean up container
                EmptyCommandContainer();
                // basic operation is
                // until all commands from the file have been read
                do
                {
                    nBytesRead += FileRead(iFileHandle,pszBuffer,iFileLength);
                    // quick check to see if initial read is stuffed..
                    if(nBytesRead == 0)
                        break;
                    // move the contents into a more useful AnsiString and clean
                    // up
                    asContents = pszBuffer;
                    delete [] pszBuffer;
                    // Process the individual commands into sequesnce of commands
                    iBeginPos = 1;
                    iEndPos   = asContents.AnsiPos(",");
                    // Until the "just read" contents are fully processed
                    while(iEndPos)
                    {
                        // Get the tokenized command string and remove any
                        // EOL or spaces or control chars from front and back
                        string sCommand = Trim((asContents.SubString(iBeginPos,(iEndPos-iBeginPos)))).c_str();
                        // insert into our map container.  note insert used as
                        // this is more efficient than 'map[key]=value' when
                        // inserting new keys.
//                        m_CommandBlock.insert(CommandBlock::value_type(sCommand,sCommand));
                        // add it to deque.
                        TCommand *pCommand = new TCommand(sCommand);
                        if(pCommand)
                            m_CommandList.push_back(pCommand);
                        // Remove the processed command from out buffer, notice
                        // we step the endpos up one to include the delimiter (eg comma)
                        asContents.Delete(iBeginPos,++iEndPos);
                        // Any more commands to process??
                        iEndPos   = asContents.AnsiPos(DELIMITER);
                    }
                    // Make sure we've deleted ant remaining remmants before proceeding
                    asContents.Delete(1,asContents.Length());
                    // keep going until we've drained the contents..
                } while(nBytesRead < iFileLength);
                FileClose(iFileHandle);
                if(nBytesRead>0)
                    bReturn = true;
            }// if iFileHandle valid
        } // ..try..
        catch(...)
        {
            ShowMessage("There was an error processing the file");
            if(iFileHandle)
                FileClose(iFileHandle);
        }
    }
    return bReturn;
}


bool __fastcall TForm2::EmptyCommandContainer()
{
    bool bReturn = true;

    if(!m_CommandList.empty())
    {
        CommandIterator = m_CommandList.begin();
        while(CommandIterator != m_CommandList.end())
        {
            delete *CommandIterator;
            CommandIterator++;
        }
        m_CommandList.clear();
    }
    return bReturn;
}

// Added 29th Jan 2009
// Needed ability to 'blap' MASsoft with a close command until success!
void __fastcall TForm2::Close1Click(TObject *Sender)
{
//    AnsiString asCommand("-xClose\r\n");
    AnsiString asCommand(GetRepeatCommand());
    m_bCloseRep = true;
    if(!Send(asCommand))
    {
        m_bCloseRep = false;
    }
}

AnsiString __fastcall TForm2::GetRepeatCommand()
{
    // Read the command from the hiden.ini file
    char szBuffer[256];
    GetPrivateProfileString("Client","RepeatCommand","-xClose",&szBuffer[0],256,"hiden.ini");
    AnsiString asCommand(&szBuffer[0]);
    if(asCommand.Length())
        asCommand += "\r\n";
    return asCommand;
}

AnsiString __fastcall TForm2::GetReply()
{
    return ansiReceived;
}

//---------------------------------------------------------------------------

void __fastcall TForm2::FloodCommands1Click(TObject *Sender)
{
    bFlood = !bFlood;
    FloodCommands1->Checked = bFlood;

    if(pContinue)
    {
        pContinue->WaitForResponse(bFlood);
    }


}
//---------------------------------------------------------------------------
bool __fastcall TForm2::CloseSocket()
{
    bool bReturn=false;

    if(ClientSocket->Active)
    {
        DisconnectServerClick(this);
        bReturn = true;
    }

    return bReturn;
}

bool __fastcall TForm2::OpenSocket()
{
    ConnectToServerClick(this);
    return true;
}





