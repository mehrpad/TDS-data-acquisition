//---------------------------------------------------------------------------
#ifndef TCommandH
#define TCommandH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <string>
using namespace std;

//---------------------------------------------------------------------------
class TSendCommand : public TThread
{
private:
    TStringList *tslList;
    bool bTerminate;
    bool bWaitResponse;
    int wIndex;
    // Private Methods.
    void __fastcall Initialize( TStringList *tslCommands);
    bool __fastcall ProcessCommand();
protected:
    void __fastcall Execute();
public:
    __fastcall TSendCommand(bool CreateSuspended,TStringList *tslCommands);
    void __fastcall Terminate(bool bTerm) {bTerminate = bTerm;}
    void __fastcall WaitForResponse(bool bWait) {bWaitResponse = bWait;}


};

class TCommand
{
    private:
        string m_sCommand;
        string m_sResponse;

    public:
        TCommand() {;}
        TCommand(string sInput) {SetCommand(sInput);}

        ~TCommand() {;}

        void SetCommand(string sInput)  {m_sCommand  = sInput;}
        void SetResponse(string sInput) {m_sResponse = sInput;}

        string GetCommand() {return  m_sCommand;}
        string GetResponse() {return m_sResponse;}

        bool ReceivedReply() {return !m_sResponse.empty();}
};
//---------------------------------------------------------------------------
#endif
